from typing import Literal

from app.models.graph import GraphState
from app.models.nodes.plan import RetrievalStep


def should_respond(state: GraphState) -> Literal["summarizer", "responder"]:
    """Determine whether to route to summarizer or directly to responder.

    Examines the planner output to decide the next step in the workflow.
    Routes to responder for simple queries that don't need summarization (1 step only),
    otherwise routes to the summarizer for information gathering (more than 1 step).

    Args:
        state: Current graph state containing planner output

    Returns:
        Name of the next node to route to ("summarizer" or "responder")
    """
    steps: list[RetrievalStep] = state.nodes["planner"].output.steps
    if len(steps) == 1:
        return "responder"
    return "summarizer"


def allowed_query(state: GraphState) -> Literal["planner", "prohibited"]:
    """Determine whether to route to planner or prohibited.

    Examines the analyzer output to decide the next step in the workflow.
    Routes to planner for allowed queries, otherwise routes to prohibited.

    Args:
        state: Current graph state containing analyzer output

    Returns:
        Name of the next node to route to ("planner" or "prohibited")
    """
    decision = state.nodes["analyzer"].output.decision
    if decision == "allowed":
        return "planner"
    return "prohibited"
