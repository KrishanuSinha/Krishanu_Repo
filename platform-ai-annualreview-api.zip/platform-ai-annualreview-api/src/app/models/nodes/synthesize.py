from pydantic import BaseModel, Field, field_validator


class Reference(BaseModel):
    """Citation reference for a source document.

    Represents a single reference to a source document used in the
    response, including its location and identifier for citation.

    Attributes:
        id: Unique sequential identifier for the reference
        title: Title of the referenced document
        url: Path or URL to the source document
        page: Page number where the information was found
    """

    id: int = Field(description="Unique sequential identifier for the reference.", ge=1)
    title: str
    url: str = Field(
        description="Path or URL to the context page/document.",
    )
    page: int


class FinalResponse(BaseModel):
    """Final response with citations.

    Structured response containing the answer text with citations
    and the list of references used in those citations.

    Attributes:
        answer: Complete answer text with in-text citations
        references: List of reference entries for the citations
    """

    answer: str = Field(
        description="The complete answer text based solely on the provided context. The answer must include in-text citations in the format [id] corresponding to the references."
    )
    references: list[Reference] = Field(
        description="List of unique reference entries indicating where the supporting information was found. Multiple pieces of information from the same page and document should use the same reference ID to avoid confusing the end user."
    )

    @field_validator("references", mode="after")
    @classmethod
    def validate_unique_references(cls, references: list[Reference]) -> list[Reference]:
        """Validate that references have unique IDs and content.

        Ensures that each reference has a unique ID and that there are no
        duplicate references to the same document page.

        Args:
            references: List of references to validate

        Returns:
            The validated list of references

        Raises:
            ValueError: If duplicate reference IDs or content are found
        """
        seen_ids: set[int] = set()
        seen_url_pages: set[tuple[str, int]] = set()

        for ref in references:
            if ref.id in seen_ids:
                raise ValueError(f"Duplicate reference id: {ref.id}")

            url_page = (ref.url, ref.page)
            if url_page in seen_url_pages:
                raise ValueError(f"Duplicate reference content: URL '{ref.url}' and page {ref.page}")

            seen_ids.add(ref.id)
            seen_url_pages.add(url_page)

        return references
