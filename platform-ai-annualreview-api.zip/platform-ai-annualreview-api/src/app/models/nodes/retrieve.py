from instructor import Image as InstructorImage
from pydantic import BaseModel


class Document(BaseModel):
    """Retrieved document model.

    Represents a single document or document fragment retrieved from
    the knowledge base, including metadata and content.

    Attributes:
        id: Unique identifier for the document
        title: Document title
        category: Document category (Annual Report, etc.)
        year: Publication year
        url: Path or URL to the source document
        page: Page number within the document
        type: Content type (text or image)
        content: The actual document content
    """

    id: int
    title: str
    category: str
    year: int
    url: str
    page: int
    type: str
    content: str | InstructorImage


class RetrievalContext(BaseModel):
    """Collection of retrieved documents.

    Container for multiple documents retrieved from the knowledge base
    that will be processed by subsequent nodes.

    Attributes:
        documents: List of retrieved documents
    """

    documents: list[Document]
