from dataclasses import dataclass, field
from typing import Annotated, Any

from openai.types.chat import ChatCompletionMessageParam


def merge_dicts(old: dict[str, Any], new: dict[str, Any]) -> dict[str, Any]:
    """Merge two dictionaries by updating the old one with values from the new one.

    Used for combining node results in the graph state.

    Args:
        old: Original dictionary to update
        new: Dictionary with new values to add

    Returns:
        Updated dictionary with combined values
    """
    old.update(new)
    return old


@dataclass(slots=True)
class NodeResult:
    """Container for the output and usage metrics of a node execution.

    Stores both the actual output data and optional usage information
    such as token counts.

    Attributes:
        output: The result data produced by the node
        usage: Optional metrics about resource usage during execution
    """

    output: Any
    usage: Any | None = field(default=None)


@dataclass(slots=True)
class GraphState:
    """State container for the LangGraph workflow.

    Maintains the current state of the graph execution, including
    the original query, message history, and results from each node.

    Attributes:
        query: The original user query being processed
        messages: List of chat messages in the conversation
        nodes: Dictionary mapping node names to their execution results
    """

    query: str
    messages: list[ChatCompletionMessageParam]
    nodes: Annotated[dict[str, NodeResult], merge_dicts] = field(default_factory=dict)
