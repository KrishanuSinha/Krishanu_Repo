from pathlib import Path

import newrelic.agent

from app.config.settings import Settings


def initialize_newrelic(settings: Settings) -> None:
    """Initialize New Relic agent.

    Initialize the New Relic agent with the given settings.

    Args:
        settings: Settings object containing the environment and New Relic API key

    Raises:
        ValueError: If the environment variable NEW_RELIC_API_KEY is not set
    """

    newrelic_ini_path = Path(settings.newrelic_ini_path)

    if not settings.newrelic_api_key:
        raise ValueError("The environment variable NEW_RELIC_API_KEY is not set.")

    # Update license key
    with newrelic_ini_path.open("r") as file:
        lines = file.readlines()

    with newrelic_ini_path.open("w") as file:
        for line in lines:
            if line.startswith("license_key ="):
                file.write(f"license_key = {settings.newrelic_api_key}\n")
            else:
                file.write(line)

    newrelic.agent.initialize(config_file=newrelic_ini_path, environment=settings.env)
