import functools
from time import perf_counter
from typing import Any, Callable, Coroutine

from langchain_core.runnables.config import RunnableConfig
from loguru import logger

from app.nodes.base import Node


def time_execution(
    func: Callable[..., Coroutine[Any, Any, Any]],
) -> Callable[..., Coroutine[Any, Any, Any]]:
    """Decorator to measure and log execution time of async node functions.

    Wraps an async function to log its start and end times, and calculate
    the total execution duration. Particularly useful for monitoring
    performance of LangGraph nodes.

    Args:
        func: Asynchronous function to be timed

    Returns:
        Wrapped function that logs timing information
    """

    @functools.wraps(func)
    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        self_instance = args[0] if args else None
        node_name = getattr(self_instance, "name", func.__name__)
        logger.debug("Starting node: {function}", function=node_name)
        start = perf_counter()
        result = await func(*args, **kwargs)
        elapsed = perf_counter() - start
        logger.debug(
            "Finished node: {function} ({s:.4f} seconds)",
            function=node_name,
            s=elapsed,
        )
        return result

    return wrapper


def update_langsmith_metadata(
    node: Node, config: RunnableConfig, usage: Any = None, model_name: str | None = None
) -> None:
    """
    Update metadata in config for LangSmith tracking.

    Args:
        node : Node object with a 'name' attribute.
        config : Configuration dictionary containing metadata.
        usage : Usage object(s) containing token information.
        model_name : Model name to include in metadata.
    """
    # Ensure metadata key exists
    metadata = config.setdefault("metadata", {})

    # Base metadata update
    metadata["node"] = node.name

    if model_name:
        metadata["model_name"] = model_name

    # Default token values
    prompt_tokens = 0
    completion_tokens = 0

    # If usage is provided, extract token info
    if usage:
        if isinstance(usage, list):
            prompt_tokens = sum(getattr(getattr(u, "usage", None), "input_tokens", 0) for u in usage)  # type: ignore
            completion_tokens = sum(getattr(getattr(u, "usage", None), "output_tokens", 0) for u in usage)  # type: ignore
        else:
            usage_data = getattr(usage, "usage", None)
            prompt_tokens = getattr(usage_data, "input_tokens", 0) if usage_data else 0
            completion_tokens = getattr(usage_data, "output_tokens", 0) if usage_data else 0

    # Update token information only if usage is provided
    if usage and prompt_tokens and completion_tokens:
        metadata.update(
            {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": prompt_tokens + completion_tokens,
            }
        )
