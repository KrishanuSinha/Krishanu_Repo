from app.baml_client.types import FinalResponse as BamlFinalResponse
from app.models.nodes.synthesize import FinalResponse


def format_response(final_response: FinalResponse | BamlFinalResponse, include_references_header: bool = True) -> str:
    """Format the response with references as a string.

    Creates a formatted string containing the answer text followed
    by a list of references in a readable format.

    Args:
        final_response: The final response to format
        include_references_header: Whether to include a "References:" header

    Returns:
        Formatted response string with answer and references
    """
    result = f"{final_response.answer}\n\n"

    if include_references_header:
        result += "References:\n"

    for ref in final_response.references:
        result += f"[{ref.id}] {ref.title} ({ref.url}) p. {ref.page}\n"

    return result.strip()
