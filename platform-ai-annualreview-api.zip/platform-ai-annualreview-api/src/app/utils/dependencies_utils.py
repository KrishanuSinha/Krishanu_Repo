import os

import instructor
from anthropic import AsyncAnthropicBedrock
from instructor import AsyncInstructor

from app.config.settings import Settings


async def create_bedrock_client(settings: Settings) -> AsyncAnthropicBedrock:
    """Create an asynchronous Anthropic Bedrock client.

    Configures an AWS Bedrock client for Anthropic models with the
    appropriate credentials based on the environment.

    Args:
        settings: Application settings containing AWS configuration

    Returns:
        Configured asynchronous Anthropic Bedrock client
    """
    if settings.env == "local":
        return AsyncAnthropicBedrock(
            aws_secret_key=os.environ["AWS_SECRET_ACCESS_KEY"],
            aws_access_key=os.environ["AWS_ACCESS_KEY_ID"],
            aws_session_token=os.environ["AWS_SESSION_TOKEN"],
            aws_region=settings.aws.region,
        )
    else:
        return AsyncAnthropicBedrock(aws_region=settings.aws.region, base_url=settings.aws.aws_bedrock_url)


def create_bedrock_instructor_client(
    bedrock_client: AsyncAnthropicBedrock,
) -> AsyncInstructor:
    """Create an Instructor Bedrock client.

    Wraps a Bedrock client with Instructor capabilities for structured
    output parsing and validation.

    Args:
        bedrock_client: Base Anthropic Bedrock client

    Returns:
        Instructor client for structured outputs
    """
    return instructor.from_anthropic(client=bedrock_client)
