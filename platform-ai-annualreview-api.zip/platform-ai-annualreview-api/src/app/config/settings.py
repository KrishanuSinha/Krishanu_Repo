from functools import lru_cache
from typing import Any

from dotenv import load_dotenv
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from app.config.aws_config import AWSConfig
from app.config.database_config import DatabaseConfig


class Settings(BaseSettings):
    """Application settings.

    Central configuration class that combines all application settings
    and provides default values. Uses Pydantic for validation and
    environment variable loading.

    Attributes:
        env: Environment name (development, staging, production)
        debug: Enable debug mode on the LangGraph graph for additional logging
        app_id: Unique identifier for the application
        aws: AWS-related configuration settings
        newrelic_api_key: API Key to configure new relic
        database: Database connection and configuration settings
        prompts_dir: Path to the directory containing prompt templates
        runnable_config_file: Path to the runnable configuration file
        newrelic_ini_path: Path to the New Relic configuration file
    """

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    env: str = Field(validation_alias="ENV_NAME", default_factory=str)
    debug: bool = False
    app_id: str = Field(validation_alias="APP_ID", default_factory=str)
    aws: AWSConfig = AWSConfig()
    newrelic_api_key: str = Field(validation_alias="NEW_RELIC_API_KEY", default_factory=str)
    database: DatabaseConfig = DatabaseConfig()
    prompts_dir: str = "prompts"
    runnable_config_file: str = "runnable_config.yaml"
    newrelic_ini_path: str = "newrelic.ini"

    def model_post_init(self, __context: Any) -> None:
        """Load the remaining environment variables from the .env file."""
        load_dotenv(dotenv_path=".env")

    def model_post_init(self, __context: Any) -> None:
        """Load the remaining environment variables from the .env file."""
        load_dotenv(dotenv_path=".env")


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Retrieve application settings.

    Provides a cached instance of the application settings to avoid
    repeated parsing of environment variables and initialization.
    The cache ensures the same settings object is returned for
    subsequent calls.

    Returns:
        Singleton instance of application settings
    """
    return Settings()
