from fastapi import APIRouter, status

router = APIRouter(prefix="/v1/annualreview", tags=["health"])


@router.get("/health", status_code=status.HTTP_200_OK)
async def health_liveness() -> dict[str, str]:
    """Check if the application is running.

    Simple endpoint that returns a success response if the application
    is up and running. Used by infrastructure for liveness probes.

    Returns:
        Status message indicating the application is operational
    """
    return {"status": "ok"}
