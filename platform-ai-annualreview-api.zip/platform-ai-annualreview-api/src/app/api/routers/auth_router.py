import json
import logging
import os
from datetime import datetime, timedelta, timezone
from typing import Annotated

import cryptocode
from fastapi import APIRouter, Depends, HTTPException, Response, status
from httpcore import PoolTimeout
from psycopg import AsyncConnection
from pydantic import UUID4

from app.api.dependencies import get_db_conn
from app.database.queries import get_app_config_data

router = APIRouter(prefix="/v1/annualreview", tags=["auth_router"])

logging.basicConfig(
    level=logging.WARNING, format="%(asctime)s - %(filename)s - %(funcName)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def encrypt_string(input_string: str) -> str:
    return cryptocode.encrypt(input_string, os.environ.get("CIPHER_KEY"))  # type: ignore


@router.options("/auth/app_id/{app_id}")
def login_options():
    headers = {
        "Access-Control-Allow-Headers": "Authorization,Content-Type,X-Amz-Date,X-Amz-Security-Token,X-Api-Key",
        "Access-Control-Allow-Methods": "*",
        "Access-Control-Allow-Origin": "*",
        "CF-Cache-Status": "DYNAMIC",
        "Allow": "*",
    }
    return Response(content="OK", status_code=200, headers=headers)


@router.get("/auth/app_id/{app_id}", status_code=status.HTTP_200_OK)
async def login(
    app_id: UUID4, db_conn: Annotated[AsyncConnection, Depends(get_db_conn)], response: Response
) -> dict[str, str]:
    try:
        logger.info("Fetching data from database")
        # Fetch configuration data from the database using app_id
        data = await get_app_config_data(db_conn, app_id)
        if not data:
            raise HTTPException(status_code=404, detail=f"No data found for the app_id {app_id}")
        now = datetime.now(timezone.utc)

        # Extract expiry duration from metadata
        expiry_seconds = 3600  # Default to 1 hour if not set in DB
        expiry_value = data.get("cmetadata", {}).get("expiry")

        if expiry_value is not None:
            expiry_seconds = int(expiry_value)

        expiry_timedelta = timedelta(seconds=expiry_seconds)

        # Prepare the response data
        response_data = {
            "app_id": data.get("id"),
            "allowed_routes": data.get("cmetadata", {}).get("allowed_routes"),
            "allowed_origins": data.get("cmetadata", {}).get("allowed_origin"),
            "timestamp": str(now),
        }
        # Convert the data to JSON string
        json_string = json.dumps(response_data)

        # Encrypt the JSON string
        encrypted_response = encrypt_string(json_string)
        # Set the cookie with dynamic expiry
        response.set_cookie(
            key="api_key",
            value=encrypted_response,
            max_age=int(expiry_timedelta.total_seconds()),
            expires=now + expiry_timedelta,
            httponly=True,
            secure=True,
            samesite="strict",
        )

        return {"api_key": encrypted_response}

    except PoolTimeout as e:
        logger.error(f"Database connection pool timeout: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Database connection pool is exhausted, try again later.")
    except Exception:
        logger.error("Unexpected error occurred", exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")
