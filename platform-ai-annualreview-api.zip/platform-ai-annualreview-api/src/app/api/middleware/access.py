import json
import os
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib.parse import unquote_plus

import cryptocode
from fastapi import HTTPException, WebSocket
from fastapi.requests import HTTPConnection
from loguru import logger
from starlette.types import ASGIApp, Receive, Scope, Send

from app.database.queries import get_app_config_data


class WebSocketAuthException(Exception):
    """Custom exception for WebSocket authentication errors."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(self.message)


async def decrypt_string(encrypted_string: str, request: HTTPConnection, is_websocket: bool = False) -> dict[Any, Any]:
    decrypted = cryptocode.decrypt(encrypted_string, os.environ.get("CIPHER_KEY"))
    if not decrypted:
        error_message = "Invalid encrypted data or decryption failed"
        raise (
            WebSocketAuthException(error_message)
            if is_websocket
            else HTTPException(status_code=400, detail=error_message)
        )

    try:
        decrypted_data = json.loads(decrypted)
        timestamp_str = decrypted_data.get("timestamp")

        if not timestamp_str:
            raise (
                WebSocketAuthException("Timestamp not found in decrypted data")
                if is_websocket
                else HTTPException(status_code=400, detail="Timestamp not found in decrypted data")
            )

        timestamp_dt = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S.%f%z")
        current_time = datetime.now(timezone.utc)

        allowed_routes = decrypted_data.get("allowed_routes")
        allowed_origins = decrypted_data.get("allowed_origins")
        app_id = decrypted_data.get("app_id")

        # Use app.state.pool directly
        db_pool = request.state.pool

        async with db_pool.connection() as conn:
            config_data = await get_app_config_data(conn=conn, app_id=app_id)

        if config_data is None:
            raise (
                WebSocketAuthException("Failed to fetch config data from database")
                if is_websocket
                else HTTPException(status_code=500, detail="Failed to fetch config data")
            )

        config_metadata = config_data.get("cmetadata", {})
        config_allowed_routes = config_metadata.get("allowed_routes")
        config_allowed_origins = config_metadata.get("allowed_origin")
        config_expiry = config_metadata.get("expiry")

        if config_expiry is not None:
            expiry_value = int(config_expiry)

            if timestamp_dt < current_time - timedelta(seconds=expiry_value):
                if is_websocket:
                    raise WebSocketAuthException("Encrypted data is expired")
                else:
                    raise HTTPException(status_code=400, detail="Encrypted data is expired")

        if allowed_routes != config_allowed_routes or allowed_routes is None:
            raise (
                WebSocketAuthException("Allowed routes mismatch")
                if is_websocket
                else HTTPException(status_code=403, detail="Allowed routes mismatch")
            )

        # Allowed Origins Check
        if allowed_origins != config_allowed_origins or allowed_origins is None:
            raise (
                WebSocketAuthException("Allowed origins mismatch")
                if is_websocket
                else HTTPException(status_code=403, detail="Allowed origins mismatch")
            )

        return decrypted_data

    except (json.JSONDecodeError, ValueError):
        error_message = "Invalid decrypted data format"
        raise (
            WebSocketAuthException(error_message)
            if is_websocket
            else HTTPException(status_code=400, detail=error_message)
        )


class APIKeyDecryptionMiddleware:
    """Custom ASGI middleware to handle WebSocket authentication before reaching the route."""

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """
        Intercepts WebSocket connections for authentication before they reach the route.
        """
        if scope["type"] == "http":
            await self.app(scope, receive, send)

        elif scope["type"] == "websocket":
            websocket = WebSocket(scope, receive, send)
            await self.process_websocket_request(websocket)

        else:
            await self.app(scope, receive, send)

    async def process_websocket_request(self, websocket: WebSocket) -> None:
        """Handles WebSocket authentication before allowing the connection."""
        query_params = websocket.query_params

        raw_token = query_params.get("apiKey")
        api_key = unquote_plus(raw_token).replace(" ", "+").strip() if raw_token else None

        if not api_key:
            await websocket.accept()
            await websocket.close(code=1008, reason="API Key is missing")
            return

        try:
            if "state" not in websocket.scope:
                websocket.scope["state"] = {}

            # Wrap into FastAPI-style request for dependency compatibility
            request = HTTPConnection(websocket.scope)

            decrypted_data = await decrypt_string(api_key, request, is_websocket=True)

            if not hasattr(websocket.state, "pool") or not hasattr(websocket.state, "graph"):
                raise WebSocketAuthException("WebSocket dependencies are not initialized. Check app startup.")

            # Attach decrypted data to WebSocket state
            websocket.scope["state"]["decrypted_message"] = decrypted_data

            logger.info("WebSocket dependencies initialized successfully.")

            # Continue WebSocket connection to the route
            await self.app(websocket.scope, websocket.receive, websocket.send)

        except WebSocketAuthException as e:
            logger.error("WebSocket authentication error: %s", e.message)
            await websocket.accept()
            await websocket.close(code=1008, reason=e.message)

        except Exception:
            logger.exception("Unexpected WebSocket error")
            await websocket.accept()
            await websocket.close(code=1011, reason="Internal Server Error")
