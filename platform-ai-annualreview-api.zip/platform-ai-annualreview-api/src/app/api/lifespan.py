from contextlib import asynccontextmanager
from typing import Any, AsyncIterator, TypedDict

from aiobotocore.session import get_session
from baml_py import Collector
from fastapi import FastAPI
from langgraph.graph import END, START
from langgraph.graph.state import CompiledStateGraph
from psycopg_pool import AsyncConnectionPool

from app.config.settings import get_settings
from app.database.connection import create_db_connection_pool
from app.database.queries import create_tables
from app.edges.conditional_edges import allowed_query, should_respond
from app.models.graph import GraphState
from app.nodes import Analyzer, Planner, Retriever, Summarizer, Synthesizer
from app.nodes.prohibited import Prohibited
from app.nodes.respond import Responder
from app.services import GraphBuilder
from app.services.prompt_handler import PromptHandler
from app.utils.config_utils import get_runnable_config
from app.utils.dependencies_utils import (
    create_bedrock_client,
    create_bedrock_instructor_client,
)


class AppState(TypedDict):
    """Application state container for FastAPI.

    Holds essential resources needed throughout the application lifecycle,
    including database connection pool, compiled state graph, and BAML Collector.

    Attributes:
        pool: Database connection pool for database operations
        graph: Compiled LangGraph workflow for processing queries
        collector: BAML Collector for collecting usage data
        app_id: Unique identifier for the application
        runnable_config: Runnable configuration
    """

    pool: AsyncConnectionPool
    graph: CompiledStateGraph
    collector: Collector
    app_id: str
    runnable_config: dict[str, Any]


@asynccontextmanager
async def app_lifespan(app: FastAPI) -> AsyncIterator[AppState]:
    """Manages the application lifecycle and resources.

    Sets up all necessary resources when the application starts and
    properly cleans them up when the application shuts down. This includes:
    - Database connections
    - External service clients
    - LangGraph workflow setup

    Args:
        app: The FastAPI application instance

    Yields:
        Application state containing database pool and compiled graph
    """
    # Load configuration.
    settings = get_settings()

    # Create database connection pool.
    pool = create_db_connection_pool(settings=settings)
    await pool.open()
    await create_tables(pool=pool)

    # Create external service clients.
    aiobotocore_session = get_session()
    bedrock_client = await create_bedrock_client(settings=settings)
    bedrock_instructor_client = create_bedrock_instructor_client(bedrock_client=bedrock_client)

    # Create prompt handler.
    prompt_handler = PromptHandler(prompts_dir=settings.prompts_dir)

    # Load runnable config.
    runnable_config = get_runnable_config(config_file=settings.runnable_config_file)

    # Instantiate BAML Collector
    collector = Collector(name="baml-langgraph-collector")

    # Instantiate the nodes of the graph.
    analyzer = Analyzer(instructor_client=bedrock_instructor_client, prompt_handler=prompt_handler)
    planner = Planner(instructor_client=bedrock_instructor_client, prompt_handler=prompt_handler)
    retriever = Retriever(aiobotocore_session=aiobotocore_session, settings=settings)
    summarizer = Summarizer(
        instructor_client=bedrock_instructor_client,
        prompt_handler=prompt_handler,
    )
    synthesizer = Synthesizer(collector=collector, settings=settings)
    responder = Responder(collector=collector, settings=settings)
    prohibited = Prohibited()

    # Prepare nodes and edges for the graph.
    nodes = {
        "analyzer": analyzer,
        "planner": planner,
        "retriever": retriever,
        "summarizer": summarizer,
        "synthesizer": synthesizer,
        "responder": responder,
        "prohibited": prohibited,
    }

    edges = [
        (START, "analyzer"),
        ("planner", "retriever"),
        ("summarizer", "synthesizer"),
        ("synthesizer", END),
        ("responder", END),
        ("prohibited", END),
    ]

    # Build and compile the graph.
    graph_builder = GraphBuilder(state_schema=GraphState)
    graph_builder.add_nodes(nodes=nodes)
    graph_builder.add_edges(edges=edges)
    graph_builder.add_conditional_edges(source="analyzer", condition=allowed_query)
    graph_builder.add_conditional_edges(source="retriever", condition=should_respond)
    graph = graph_builder.compile(debug=settings.debug)

    yield {
        "pool": pool,
        "graph": graph,
        "collector": collector,
        "app_id": settings.app_id,
        "runnable_config": runnable_config,
    }

    # Close database connection pool.
    await pool.close()

    # Close external connections.
    await bedrock_client.close()
