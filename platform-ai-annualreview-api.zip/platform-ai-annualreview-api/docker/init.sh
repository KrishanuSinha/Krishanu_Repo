#!/bin/bash

# vault agent -config=/vault-agent-${ENVIRONMENT}.hcl
if [ "${ENVIRONMENT}" = "prod" ]
then
        vault agent -config=/app/vault-agent-prod.hcl
elif [ "${ENVIRONMENT}" = "stage" ]
then
        vault agent -config=/app/vault-agent-stage.hcl
else
        vault agent -config=/app/vault-agent-dev.hcl
fi

uvicorn server:app --host 0.0.0.0 --port 443 --ssl-keyfile /etc/ssl/server.key --ssl-certfile /etc/ssl/server.crt 
# --log-level debug
