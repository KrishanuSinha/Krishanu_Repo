from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.lifespan import app_lifespan
from app.api.middleware import access
from app.api.routers import auth_router, chat, health
from app.config.settings import get_settings
from app.utils.newrelic_utils import initialize_newrelic

initialize_newrelic(settings=get_settings())

app = FastAPI(
    lifespan=app_lifespan,
    title="Annual Report",
    description="Annual Report API",
)

app.add_middleware(
    CORSMiddleware,
    allow_origin_regex = r"https://.*\.(informa|iiris)\.com|http://localhost:\d+|https?://.*\.luminous\.co\.uk",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)

app.add_middleware(access.APIKeyDecryptionMiddleware)

app.include_router(health.router)
app.include_router(chat.router)
app.include_router(auth_router.router)
