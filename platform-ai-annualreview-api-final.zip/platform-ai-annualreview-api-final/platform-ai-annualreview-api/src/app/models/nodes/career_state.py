from typing import List, Literal, Optional, Dict, Any
from pydantic import BaseModel

Persona = Literal["IC","Manager","SeniorLeader"]
Intent = Literal["job","courses","development_plan","manager_toolkit","leadership_strategy","profile"]

class Profile(BaseModel):
    employee_id: Optional[str] = None
    name: Optional[str] = None
    title: Optional[str] = None
    band: Optional[str] = None
    division: Optional[str] = None
    skills: List[str] = []
    interests: List[str] = []

class SessionState(BaseModel):
    employee_id: Optional[str] = None
    persona: Optional[Persona] = "IC"
    intents: List[Intent] = []
    profile: Optional[Profile] = None
    extracted_skills: List[str] = []
    confirmed_skills: List[str] = []
    gaps: List[str] = []
    job_hits: List[Dict[str, Any]] = []
    course_hits: List[Dict[str, Any]] = []
    correlation_id: Optional[str] = None
