from typing import Literal

from pydantic import (
    BaseModel,
    Field,
    ValidationInfo,
    field_validator,
)


class RetrievalStep(BaseModel):
    """Single step in a retrieval plan.

    Represents a specific document retrieval operation with category,
    year, and query information. Includes validation to ensure that
    requested documents exist in the knowledge base.

    Attributes:
        category: Type of document to retrieve (Annual Report, etc.)
        year: Publication year of the document
        query: Specific query to extract information from the document
    """

    category: Literal[
        "All Documents",
        "Annual Report",
        "Climate Impacts Report",
        "Sustainability Report",
        "Press Release",
    ] = Field(
        description="Type of document to query.",
        default="All Documents",
    )
    year: int = Field(
        description="Report year to query. Defaults to the latest available year for that document type if unspecified.",
    )
    query: str = Field(
        description="Specific and targeted query for extracting the required information from that document.",
    )

    @field_validator("year", mode="after")
    @classmethod
    def validate_year(cls, v: int, info: ValidationInfo) -> int:
        """Validate that the requested year is available for the document category.

        Ensures that the year is within the valid range for the selected
        document category to prevent requests for non-existent documents.

        Args:
            v: The year value to validate
            info: Validation context containing other field values

        Returns:
            The validated year value

        Raises:
            ValueError: If the year is invalid for the selected category
        """
        category = info.data.get("category")
        if category == "Annual Report" and not 2002 <= v <= 2024:
            raise ValueError("Annual Report year must be between 2002 and 2024.")
        elif category == "Climate Impacts Report" and v != 2024:
            raise ValueError("Climate Impacts Report year must be 2024.")
        elif category == "Press Release" and v not in [2023, 2024, 2025]:
            raise ValueError("Press Release year must be 2023, 2024, or 2025.")
        elif category == "Sustainability Report" and not 2010 <= v <= 2024:
            raise ValueError("Sustainability Report year must be between 2010 and 2024.")
        return v


class RetrievalStepList(BaseModel):
    """Collection of retrieval steps forming a complete retrieval plan.

    Contains the sequence of retrieval operations needed to gather
    all information required to answer a user query.

    Attributes:
        steps: List of retrieval steps to execute
    """

    steps: list[RetrievalStep] = Field(
        description="Efficient plan for retrieving the necessary data while minimizing processing costs."
    )
