from typing import List, Literal
Intent = Literal["job","courses","development_plan","manager_toolkit","leadership_strategy","profile"]
Persona = Literal["IC","Manager","SeniorLeader"]
