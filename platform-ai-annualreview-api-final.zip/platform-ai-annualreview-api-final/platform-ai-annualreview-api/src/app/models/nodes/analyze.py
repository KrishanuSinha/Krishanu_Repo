from typing import Literal

from pydantic import BaseModel, Field


class Decision(BaseModel):
    """Decision model for analyzer node.

    Represents the outcome of the analyzer node that determines
    whether specific queries are permitted based on defined criteria.

    Attributes:
        query_breakdown: thought process of the intent that influenced the decision.
        reason: The reason for the decision
        decision: The determination result, either "allowed" or "not_allowed"
    """

    query_breakdown: str = Field(
        description=(
            "A very brief analysis (50 words or less) that explains why the query is allowed or not allowed. "
            "Focus only on the most critical factor that determined the decision."
        )
    )
    reason: Literal["future_related", "opinion_related", "not_related", "overwriting_format_or_sources", "allowed"] = (
        Field(
            description=(
                "The reason for not allowing the query. "
                "If the query involves specific future numerical predictions, financial forecasts, or speculative financial information, "
                "it should be marked as 'future_related'. "
                "If the query involves subjective opinions, personal judgments, or requests for evaluative assessments rather than factual information, "
                "it should be marked as 'opinion_related'. "
                "If the query is not related to the company's financial information, "
                "it should be marked as 'not_related'. "
                "If the query is overwriting the format or sources of the response, "
                "it should be marked as 'overwriting_format_or_sources'. "
                "Finally, if the query is allowed, it should be marked as 'allowed'."
            )
        )
    )
    decision: Literal["allowed", "not_allowed"] = Field(...)
