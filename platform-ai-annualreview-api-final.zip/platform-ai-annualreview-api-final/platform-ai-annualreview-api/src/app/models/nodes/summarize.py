from pydantic import BaseModel, Field
from pydantic_xml import BaseXmlModel, attr, element


class Summary(BaseModel):
    """Simple summary model.

    Basic model for document summaries.

    Attributes:
        content: The summarized content with citation markers
    """

    content: str = Field(description="Concise summary with [number] citations.")


class XMLReferences(BaseXmlModel, tag="references"):
    """XML-compatible reference model.

    Represents a citation reference in XML format for structured output.

    Attributes:
        id: Unique identifier for the reference
        title: Title of the referenced document
        url: Path or URL to the source document
        page: Page number where the information was found
    """

    id: int = attr()
    title: str = element()
    url: str = element()
    page: int = element()


class XMLSummaryWithReferences(BaseXmlModel, tag="summary"):
    """XML-compatible summary with structured references.

    Combines summary content with a list of references in XML format.

    Attributes:
        content: The summarized content with citation markers
        references: List of structured references for the citations
    """

    content: str
    references: list[XMLReferences]
