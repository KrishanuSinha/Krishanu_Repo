from typing import List, Dict, Any
from pydantic import BaseModel

class JobHit(BaseModel):
    id: str
    title: str
    division: str
    band: str
    similarity: float
    reasons: List[str] = []
