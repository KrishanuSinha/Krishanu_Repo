from typing import List
from pydantic import BaseModel

class GapSummary(BaseModel):
    missing_skills: List[str] = []
    priority: List[str] = []
