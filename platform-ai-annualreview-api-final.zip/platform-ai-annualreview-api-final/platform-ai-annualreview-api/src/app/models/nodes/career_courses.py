from typing import List
from pydantic import BaseModel

class CourseHit(BaseModel):
    id: str
    title: str
    provider: str
    url: str | None = None
    covers_skills: List[str] = []
