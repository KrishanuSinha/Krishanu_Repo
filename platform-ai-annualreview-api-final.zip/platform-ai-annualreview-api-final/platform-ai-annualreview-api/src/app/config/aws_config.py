from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class AWSConfig(BaseSettings):
    """AWS configuration.

    Defines AWS-specific settings required for connecting to Amazon Bedrock services.
    Values are loaded from environment variables.

    Attributes:
        region: AWS region where services are deployed
        knowledge_base_id: Identifier for the Amazon Bedrock Knowledge Base
            used for retrieval and document storage
    """

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    region: str = Field(validation_alias="AWS_BEDROCK_REGION", default="eu-west-1")
    knowledge_base_id: str = Field(validation_alias="AWS_KNOWLEDGE_BASE_ID", default_factory=str)
    aws_bedrock_url: str = Field(validation_alias="AWS_BEDROCK_URL", default_factory=str)
    aws_reranking_url: str = Field(validation_alias="AWS_RERANKING_URL", default_factory=str)
