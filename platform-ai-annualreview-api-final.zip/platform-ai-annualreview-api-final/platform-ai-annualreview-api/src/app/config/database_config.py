from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class DatabaseConfig(BaseSettings):
    """Database configuration.

    Defines PostgreSQL database connection parameters and provides
    utilities for generating connection strings. Values are loaded
    from environment variables.

    Attributes:
        name: Database name to connect to
        user: Username for database authentication
        password: Password for database authentication
        host: Database server hostname or IP address
        port: Database server port number
    """

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    name: str = Field(validation_alias="DB_NAME", default_factory=str)
    user: str = Field(validation_alias="DB_USER", default_factory=str)
    password: str = Field(validation_alias="DB_PASSWORD", default_factory=str)
    host: str = Field(validation_alias="DB_HOST", default_factory=str)
    port: str = Field(validation_alias="DB_PORT", default_factory=str)

    @property
    def conninfo(self) -> str:
        """Generate PostgreSQL connection string in libpq format.

        Creates a properly formatted connection string that can be used
        with psycopg and other PostgreSQL client libraries.

        Returns:
            Formatted connection string with all necessary parameters
        """
        return f"dbname={self.name} user={self.user} password={self.password} host={self.host} port={self.port}"
