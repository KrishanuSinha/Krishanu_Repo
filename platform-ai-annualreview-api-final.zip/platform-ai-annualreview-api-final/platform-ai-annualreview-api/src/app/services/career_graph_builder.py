from typing import Callable
from langgraph.graph import StateGraph, END
from ..nodes.career import (
    profile_load, skill_extract, skill_confirm, intent_persona,
    dispatcher, jobs_kb, courses_kb, skill_gap, persona_summarize, synth_stream,
)
from ..nodes.career.types import NodeIO

# Build a minimal graph adhering to the repo's services pattern

def build_career_graph() -> Callable[[NodeIO], NodeIO]:
    g = StateGraph(NodeIO)
    g.add_node("profile_load", profile_load.run)
    g.add_node("skill_extract", skill_extract.run)
    g.add_node("skill_confirm", skill_confirm.run)
    g.add_node("intent_persona", intent_persona.run)
    g.add_node("dispatcher", dispatcher.run)
    g.add_node("jobs_kb", jobs_kb.run)
    g.add_node("courses_kb", courses_kb.run)
    g.add_node("skill_gap", skill_gap.run)
    g.add_node("persona_summarize", persona_summarize.run)
    g.add_node("synth_stream", synth_stream.run)

    g.set_entry_point("profile_load")
    g.add_edge("profile_load","skill_extract")
    g.add_edge("skill_extract","skill_confirm")
    g.add_edge("skill_confirm","intent_persona")
    g.add_edge("intent_persona","dispatcher")

    # For now, funnel to jobs -> gap -> synth to keep contract simple
    g.add_edge("dispatcher","jobs_kb")
    g.add_edge("jobs_kb","skill_gap")
    g.add_edge("skill_gap","synth_stream")
    g.add_edge("synth_stream", END)

    app = g.compile()
    return app
