from typing import Any, Callable

from langgraph.graph import StateGraph
from langgraph.graph.state import CompiledStateGraph

from app.models.graph import GraphState
from app.nodes.base import Node


class GraphBuilder:
    """Builder for creating and configuring LangGraph state graphs.

    Provides a simplified interface for constructing LangGraph workflows
    by handling node registration, edge connections, and conditional routing.

    Attributes:
        state_schema: Schema defining the structure of the graph state
        graph: The underlying StateGraph instance being built
    """

    def __init__(
        self,
        state_schema: Any = GraphState,
        config_schema: Any | None = None,
    ) -> None:
        """Initialize a new graph builder.

        Args:
            state_schema: Schema defining the structure of the graph state
            config_schema: Optional schema for configuration
        """
        self.state_schema = state_schema
        self.graph = StateGraph(state_schema=state_schema, config_schema=config_schema)

    def add_nodes(self, nodes: dict[str, Node]) -> None:
        """Register processing nodes in the graph.

        Args:
            nodes: Dictionary mapping node names to node implementations
        """
        for name, action in nodes.items():
            self.graph.add_node(node=name, action=action)

    def add_edges(self, edges: list[tuple[str, str]]) -> None:
        """Connect nodes with directed edges.

        Args:
            edges: List of (source, target) node name tuples
        """
        for source, target in edges:
            self.graph.add_edge(start_key=source, end_key=target)

    def add_conditional_edges(self, source: str, condition: Callable[[GraphState], str]) -> None:
        """Add conditional routing from a source node.

        Args:
            source: Name of the source node
            condition: Function that determines the next node based on state
        """
        self.graph.add_conditional_edges(source=source, path=condition)

    def compile(self, debug: bool = False) -> CompiledStateGraph:
        """Compile the graph into an executable form.

        Args:
            debug: Whether to enable debug mode

        Returns:
            Compiled graph ready for execution
        """
        return self.graph.compile(debug=debug)
