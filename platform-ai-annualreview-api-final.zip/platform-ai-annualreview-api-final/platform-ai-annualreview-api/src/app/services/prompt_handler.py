from pathlib import Path


class PromptHandler:
    """Prompt template manager.

    Handles loading and caching of prompt templates from the filesystem.
    Prompts are loaded from a directory structure and cached for efficient
    access during runtime.

    Attributes:
        prompts_dir: Path to the directory containing prompt templates
        _prompts_cache: Internal cache of loaded prompt templates
    """

    def __init__(self, prompts_dir: str = "prompts") -> None:
        """Initialize the prompt handler.

        Args:
            prompts_dir: Path to the directory containing prompt templates
        """
        self.prompts_dir = Path(prompts_dir)
        self._prompts_cache: dict[str, str] = {}
        self._load_all_prompts()

    def _load_all_prompts(self) -> None:
        """Load all prompt templates from the prompts directory.

        Recursively scans the prompts directory and loads all files
        into the internal cache, using their relative paths as keys.

        Raises:
            FileNotFoundError: If the prompts directory doesn't exist
        """
        if not self.prompts_dir.exists():
            raise FileNotFoundError(f"Prompts directory not found: {self.prompts_dir}")

        for file_path in self.prompts_dir.rglob("*"):
            if file_path.is_file():
                cache_key = file_path.relative_to(self.prompts_dir).as_posix()

                with open(file_path, "r", encoding="utf-8") as f:
                    self._prompts_cache[cache_key] = f.read()

    def get_prompt(self, path: str) -> str:
        """Retrieve a prompt template by its path.

        Args:
            path: Path to the prompt template, relative to the prompts directory

        Returns:
            The prompt template content

        Raises:
            KeyError: If the prompt template doesn't exist in the cache
        """
        if path not in self._prompts_cache:
            raise KeyError(f"Prompt not found: {path}")

        return self._prompts_cache[path]
