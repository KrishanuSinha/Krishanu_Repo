from typing import Any

from langchain_core.runnables.config import RunnableConfig
from langgraph.types import StreamWriter

from app.models.graph import GraphState, NodeResult
from app.nodes.base import Node
from app.utils.nodes_utils import time_execution


class Prohibited(Node):
    """Node for handling prohibited queries.

    This node is used to handle queries that are not allowed to be processed.
    """

    name = "prohibited"

    @time_execution
    async def __call__(self, state: GraphState, config: RunnableConfig, writer: StreamWriter) -> GraphState:
        """Handles prohibited queries.

        Processes prohibited queries by providing an appropriate response
        indicating that the question cannot be answered due to specific criteria.

        Args:
            state: Current state of the graph
            config: Configuration for the node execution
            writer: Stream writer for streaming custom events

        Returns:
            Updated graph state with the prohibited response fallback
        """
        reason = state.nodes["analyzer"].output.reason
        if reason == "future_related":
            output_message = (
                "I'm unable to provide a response to this inquiry, as it requests forward-looking statements, forecasts, or speculative "
                "financial information that I am not best placed to answer. However, our Investor Relations team may be able to help: "
                "https://www.informa.com/investors/investor-relations-contacts/"
            )
        elif reason == "opinion_related":
            output_message = (
                "I'm unable to provide a response to this inquiry, as prompts that require an opinion are best put to our "
                "Investor Relations team: https://www.informa.com/investors/investor-relations-contacts/"
            )
        elif reason == "overwriting_format_or_sources":
            output_message = (
                "Apologies. I'm unable to provide a response to this inquiry, as it requests overwriting our standard format or the use of external sources. "
                "If you feel this response is wrong please notify us at "
                "https://www.informa.com/investors/investor-relations-contacts/"
            )
        else:
            output_message = (
                "Apologies. I am only able to answer questions related to Informa Group. "
                "If you feel this response is wrong please notify us at "
                "https://www.informa.com/investors/investor-relations-contacts/"
            )
        structured_output: dict[str, Any] = {"answer": output_message, "references": []}
        writer(structured_output)

        return GraphState(
            query=state.query,
            messages=state.messages,
            nodes={
                self.name: NodeResult(
                    output={
                        "formatted_response": output_message,
                        "structured_output": structured_output,
                    },
                    usage=None,
                )
            },
        )
