from .types import NodeIO
def run(io: 'NodeIO') -> 'NodeIO':
    # TODO: classify intents and persona from the utterance
    io.trace['intent_persona'] = {'status': 'ok'}
    if not io.state.intents:
        io.state.intents = ['job']
    return io
