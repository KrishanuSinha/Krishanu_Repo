from .types import NodeIO
def run(io: 'NodeIO') -> 'NodeIO':
    # Placeholder dispatcher
    io.trace['dispatcher'] = {'intents': io.state.intents}
    return io
