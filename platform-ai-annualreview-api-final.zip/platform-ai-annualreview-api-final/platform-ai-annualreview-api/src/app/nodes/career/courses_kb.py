from .types import NodeIO
def run(io: 'NodeIO') -> 'NodeIO':
    # TODO: collaborative filtering based on skill gaps
    io.trace['courses_kb'] = {'count': len(io.state.course_hits)}
    return io
