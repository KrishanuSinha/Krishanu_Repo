from .types import NodeIO
from .benchmarks import benchmark_line
import random

QUOTES = [
    ("We are what we repeatedly do. Excellence, then, is not an act but a habit.", "Will Durant"),
    ("Learning never exhausts the mind.", "Leonardo da Vinci"),
    ("What we know is a drop; what we don’t know is an ocean.", "Isaac Newton"),
    ("Once you stop learning, you start dying.", "Albert Einstein"),
    ("The only limit to our realization of tomorrow is our doubts of today.", "F. D. Roosevelt"),
]

def run(io: 'NodeIO') -> 'NodeIO':
    quote, author = random.choice(QUOTES)
    brag = benchmark_line(io.state)

    sections = []
    sections.append(f"“{quote}” — {author}")
    if brag:
        sections.append(brag)

    sections.append("In 2 minutes, I’ll:\n"
                    "✅ Recommend 2 career paths in Informa\n"
                    "✅ Show the 3 most valuable skills to build next\n"
                    "✅ Give you 2 courses to start this month\n\n"
                    "Shall we begin?")

    io.trace['persona_summarize'] = {'status': 'ok', 'brag': brag is not None}
    io.trace['synth_payload'] = sections
    return io
