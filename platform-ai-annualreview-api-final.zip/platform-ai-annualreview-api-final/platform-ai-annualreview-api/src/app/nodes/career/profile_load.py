from .types import NodeIO
from ...models.nodes.career_state import SessionState, Profile

LOOKUP_BY_EMAIL_OR_ID = """
-- Fast path without vector column
SELECT e.document, e.cmetadata
FROM ai.langchain_pg_embedding e
JOIN ai.langchain_pg_collection c ON c.uuid = e.collection_id
WHERE c.name = 'internal_private_employee_profiles_vectorstore'
  AND (e.custom_id = %(employee_id)s OR (e.cmetadata->>'email') = %(email)s)
LIMIT 50;
"""

FIND_ME_FALLBACK = """
SELECT e.document, e.cmetadata
FROM ai.langchain_pg_embedding e
JOIN ai.langchain_pg_collection c ON c.uuid = e.collection_id
WHERE c.name = 'internal_private_employee_profiles_vectorstore'
  AND (e.cmetadata->>'name') ILIKE '%%' || %(name)s || '%%'
  AND (%(division)s IS NULL OR (e.cmetadata->>'division') ILIKE '%%' || %(division)s || '%%')
LIMIT 10;
"""

def run(io: 'NodeIO') -> 'NodeIO':
    # TODO: Implement DB lookups using the above SQL with your pool/DI.
    # If quick-profile info is present in session, hydrate Profile without DB.
    if not io.state.profile:
        io.state.profile = Profile(skills=[], interests=[])
    io.trace['profile_load'] = {'status': 'ok', 'source': 'placeholder'}
    return io
