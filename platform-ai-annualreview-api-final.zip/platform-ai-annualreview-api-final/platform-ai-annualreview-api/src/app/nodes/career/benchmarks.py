from __future__ import annotations
from typing import Optional, List
import statistics

# ---- Capability selection ----

CAPABILITY_MAP = {
    "data": "analytics_modeling",
    "analyst": "analytics_modeling",
    "scientist": "analytics_modeling",
    "ml": "ml_engineering",
    "backend": "systems_backend",
    "platform": "systems_backend",
    "sre": "reliability_engineering",
    "frontend": "frontend_engineering",
    "product": "product_discovery",
    "design": "ux_research",
    "manager": "hiring_coaching",
    "lead": "people_leadership",
    "director": "portfolio_strategy",
    "vp": "portfolio_strategy",
    "ops": "process_excellence",
    "support": "customer_success",
    "automation": "automation",
    "cloud": "cloud_platforms",
}

PRETTY = {
    "analytics_modeling": "analytics & modeling",
    "ml_engineering": "ML engineering",
    "systems_backend": "backend systems",
    "reliability_engineering": "site reliability",
    "frontend_engineering": "frontend engineering",
    "product_discovery": "product discovery",
    "ux_research": "UX research",
    "hiring_coaching": "hiring & coaching",
    "people_leadership": "people leadership",
    "portfolio_strategy": "portfolio strategy",
    "process_excellence": "process excellence",
    "customer_success": "customer success",
    "automation": "automation",
    "cloud_platforms": "cloud platforms",
}

def pretty(cap: str) -> str:
    return PRETTY.get(cap, cap.replace("_", " "))

def choose_capability(state) -> Optional[str]:
    title = (getattr(getattr(state, "profile", None), "title", None) or "").lower()
    interests = set([s.lower() for s in getattr(getattr(state, "profile", None), "interests", [])])
    skills = set([s.lower() for s in getattr(getattr(state, "profile", None), "skills", [])])

    for key, cap in CAPABILITY_MAP.items():
        if key in title:
            return cap

    for key, cap in CAPABILITY_MAP.items():
        if any(key in s for s in interests) or any(key in s for s in skills):
            return cap

    return None

def capability_score(profile, capability: str) -> float:
    skills = [s.lower() for s in getattr(profile, "skills", [])]
    interest_bonus = 0.05 if any(k in (getattr(profile, "interests", []) or []) for k in ("career path", "learning", "mentoring")) else 0.0
    keys = [k for k, cap in CAPABILITY_MAP.items() if cap == capability]
    hits = sum(1 for s in skills if any(k in s for k in keys))
    score = min(1.0, (hits * 0.15) + interest_bonus)
    return max(0.0, score)

def rank_percentile(score: float, peers: list[float]) -> float:
    if not peers:
        return 0.5
    sorted_peers = sorted(peers)
    below = sum(1 for p in sorted_peers if p <= score)
    return below / max(1, len(sorted_peers))

def bucketize(score: float, peers: list[float]) -> str:
    if not peers or len(peers) < 10:
        return "above average" if score >= 0.5 else "developing"
    q = statistics.quantiles(peers, n=4, method="inclusive")
    if score <= q[0]: return "bottom quartile"
    if score <= q[1]: return "below median"
    if score <= q[2]: return "above median"
    return "top quartile"

def fetch_peer_scores(persona: str | None, band: str | None, division: str | None) -> list[float]:
    base = [i/100 for i in range(10, 95, 3)]
    return base

def benchmark_line(state) -> Optional[str]:
    cap = choose_capability(state)
    if not cap or not getattr(state, "profile", None):
        return None
    score = capability_score(state.profile, cap)
    peers = fetch_peer_scores(getattr(state, "persona", "IC"), getattr(getattr(state, "profile", None), "band", None), getattr(getattr(state, "profile", None), "division", None))
    if len(peers) < 50:
        bucket = bucketize(score, peers)
        return f"Your {pretty(cap)} capability looks {bucket} for your band."
    pct = round(100 * rank_percentile(score, peers))
    if pct >= 67:
        return f"You’re stronger in {pretty(cap)} than about {pct}% of your peer group."
    if pct >= 50:
        return f"Your {pretty(cap)} capability is above the median for your peer group."
    return f"Your {pretty(cap)} capability is developing relative to peers; I’ll recommend quick wins."
