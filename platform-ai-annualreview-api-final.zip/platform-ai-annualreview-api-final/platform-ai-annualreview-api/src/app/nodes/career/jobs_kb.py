from .types import NodeIO
def run(io: 'NodeIO') -> 'NodeIO':
    # TODO: exact -> closest match against jobs table using pgvector
    io.trace['jobs_kb'] = {'count': len(io.state.job_hits)}
    return io
