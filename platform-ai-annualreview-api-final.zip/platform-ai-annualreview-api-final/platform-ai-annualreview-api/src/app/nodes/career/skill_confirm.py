from .types import NodeIO
def run(io: 'NodeIO') -> 'NodeIO':
    # TODO: ask user to confirm or add/remove skills; keep in session only
    io.trace['skill_confirm'] = {'status': 'ok'}
    return io
