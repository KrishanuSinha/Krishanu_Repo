from typing import Dict, Any
from pydantic import BaseModel
from ...models.nodes.career_state import SessionState

class NodeIO(BaseModel):
    state: SessionState
    trace: Dict[str, Any] = {}
