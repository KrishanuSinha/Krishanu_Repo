from .types import NodeIO
def run(io: 'NodeIO') -> 'NodeIO':
    # TODO: compute gap between confirmed skills and target roles
    io.trace['skill_gap'] = {'status': 'ok'}
    return io
