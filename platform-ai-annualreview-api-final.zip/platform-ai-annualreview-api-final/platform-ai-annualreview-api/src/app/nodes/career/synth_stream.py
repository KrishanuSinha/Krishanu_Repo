from .types import NodeIO

def run(io: 'NodeIO') -> 'NodeIO':
    payload = io.trace.get('synth_payload', [])
    io.trace['synth_stream'] = {'sections': len(payload)}
    return io
