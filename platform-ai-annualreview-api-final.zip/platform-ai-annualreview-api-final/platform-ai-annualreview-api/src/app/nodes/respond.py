import urllib.parse

import instructor
from baml_py import Collector, Image
from langchain_core.runnables.config import RunnableConfig
from langgraph.types import StreamWriter

from app.baml_client.async_client import b
from app.baml_client.globals import reset_baml_env_vars
from app.baml_client.types import Message
from app.config.settings import Settings
from app.models.graph import GraphState, NodeResult
from app.nodes.base import Node
from app.utils.models_utils import format_response
from app.utils.nodes_utils import time_execution, update_langsmith_metadata


class Responder(Node):
    """Generates a response without summarizing the context.

    Attributes:
        name: Identifier for this node in the graph
    """

    name = "responder"

    def __init__(self, collector: Collector, settings: Settings) -> None:
        """Initializes the Responder node.

        Args:
            collector: BAML Collector for collecting usage data
            settings: Settings for the application
        """
        self.collector = collector
        self.settings = settings

    @time_execution
    async def __call__(self, state: GraphState, config: RunnableConfig, writer: StreamWriter) -> GraphState:
        """Generates a response.

        Args:
            state: Current state of the graph
            config: Configuration for the node execution
            writer: Stream writer for streaming custom events

        Returns:
            Updated graph state with the final synthesized response

        Raises:
            KeyError: If required configuration is missing
            ValueError: If the stream does not produce any chunks
        """

        context: list[str | Image] = []

        for element in state.nodes["retriever"].output["context"][0]:
            if isinstance(element, str):
                context.append(element)
            elif isinstance(element, instructor.multimodal.Image):
                base64_image = str(element.source).split(",")[-1]
                context.append(Image.from_base64(media_type="image/png", base64=base64_image))
            else:
                raise ValueError(f"Unexpected element type: {type(element)}")

        reset_baml_env_vars({"AWS_BEDROCK_REGION": self.settings.aws.region})
        messages = [Message(role=message["role"], content=message["content"]) for message in state.messages]
        stream = b.stream.GenerateFinalResponse(
            context=context, query=state.query, messages=messages[:-1], baml_options={"collector": self.collector}
        )
        async for partial in stream:
            writer(partial.model_dump())

        model_name = None

        if hasattr(self.collector, "last") and self.collector.last and hasattr(self.collector.last, "calls"):
            for call in self.collector.last.calls:
                if call.http_response and call.http_response.status == 200 and call.http_request:
                    response_url = call.http_request.url
                    encoded_model_name = response_url.split("/model/")[1].split("/converse-stream")[0]
                    model_name = urllib.parse.unquote(encoded_model_name)
                    break

        final_response = await stream.get_final_response()
        update_langsmith_metadata(self, config, usage=self.collector.last, model_name=model_name)

        return GraphState(
            query=state.query,
            messages=state.messages,
            nodes={
                self.name: NodeResult(
                    output={
                        "structured_output": final_response.model_dump(),
                        "formatted_response": format_response(final_response=final_response),
                    }
                )
            },
        )
