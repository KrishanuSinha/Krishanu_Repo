from datetime import datetime, timezone
from typing import Any

from instructor import AsyncInstructor
from langchain_core.runnables.config import RunnableConfig
from langgraph.types import StreamWriter
from loguru import logger

from app.models.graph import GraphState, NodeResult
from app.models.nodes.plan import RetrievalStepList
from app.nodes.base import Node
from app.services.prompt_handler import PromptHandler
from app.utils.nodes_utils import time_execution, update_langsmith_metadata


class Planner(Node):
    """Creates a retrieval plan based on the user query.

    Generates a structured list of retrieval steps to gather information
    needed to answer the user's query.

    Attributes:
        name: Identifier for this node in the graph
    """

    name = "planner"

    def __init__(self, instructor_client: AsyncInstructor, prompt_handler: PromptHandler) -> None:
        """Initializes the Planner node.

        Args:
            instructor_client: Client for making structured LLM calls
            prompt_handler: Service for retrieving prompt templates
        """
        self.instructor_client = instructor_client
        self.prompt_handler = prompt_handler

    @time_execution
    async def __call__(self, state: GraphState, config: RunnableConfig, writer: StreamWriter) -> GraphState:
        """Creates a retrieval plan for answering the user query.

        Generates a structured list of retrieval steps with specific queries
        to gather the information needed to answer the user's question.

        Args:
            state: Current state of the graph
            config: Configuration for the node execution
            writer: Stream writer for streaming custom events

        Returns:
            Updated graph state with the retrieval plan

        Raises:
            KeyError: If required configuration is missing
            Exception: If both primary and fallback models fail
        """
        node_config = config.get("configurable", {}).get(self.name)
        if not node_config:
            raise KeyError(f"Configuration for node '{self.name}' is missing in 'configurable'.")

        if "model_name" not in node_config:
            raise KeyError(f"'model_name' is required in the configuration for node '{self.name}'.")

        if "fallback_model_name" not in node_config:
            raise KeyError(f"'fallback_model_name' is required in the configuration for node '{self.name}'.")

        system_prompt = [
            {
                "type": "text",
                "text": self.prompt_handler.get_prompt(path=f"{self.name}/template"),
            },
            {
                "type": "text",
                "text": f"<current_date> {datetime.now(timezone.utc).date()} </current_date>",
                "cache_control": {"type": "ephemeral"},
            },
        ]
        user_message: Any = {
            "role": "user",
            "content": [{"type": "text", "text": state.query, "cache_control": {"type": "ephemeral"}}],
        }
        messages = [*state.messages[:-1], user_message]

        primary_model = node_config["model_name"]
        fallback_model = node_config["fallback_model_name"]

        try:
            (
                structured_output,
                usage,
            ) = await self.instructor_client.chat.completions.create_with_completion(
                model=primary_model,
                response_model=RetrievalStepList,
                system=system_prompt,
                messages=messages,
                max_tokens=node_config.get("max_tokens", 1_024),
                temperature=node_config.get("temperature", 0.2),
            )

            model_name = primary_model

        except Exception as e:
            logger.warning("Primary model '{model}' failed with error: '{error}'.", model=primary_model, error=str(e))

            try:
                (
                    structured_output,
                    usage,
                ) = await self.instructor_client.chat.completions.create_with_completion(
                    model=fallback_model,
                    response_model=RetrievalStepList,
                    system=system_prompt,
                    messages=messages,
                    max_tokens=node_config.get("max_tokens", 1_024),
                    temperature=node_config.get("temperature", 0.2),
                )

                model_name = fallback_model

            except Exception as fallback_error:
                logger.error(
                    "Both primary and fallback models failed. Primary model error: '{primary_error}', Fallback model error: '{fallback_error}'",
                    primary_error=str(e),
                    fallback_error=str(fallback_error),
                )
                raise Exception(f"Both primary and fallback models failed. Error: '{str(fallback_error)}'")

        update_langsmith_metadata(node=self, config=config, usage=usage, model_name=model_name)

        return GraphState(
            query=state.query,
            messages=state.messages,
            nodes={self.name: NodeResult(output=structured_output, usage=usage)},
        )
