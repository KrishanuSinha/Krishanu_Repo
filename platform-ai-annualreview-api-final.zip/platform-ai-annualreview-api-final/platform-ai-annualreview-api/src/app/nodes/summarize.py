import asyncio
import re
from typing import Any
from uuid import uuid4

from instructor import AsyncInstructor
from langchain_core.runnables.config import RunnableConfig
from langgraph.types import StreamWriter
from loguru import logger
from openai.types.chat import (
    ChatCompletionMessageParam,
)

from app.models.graph import GraphState, NodeResult
from app.models.nodes.plan import RetrievalStep
from app.models.nodes.retrieve import Document
from app.models.nodes.summarize import (
    Summary,
    XMLReferences,
    XMLSummaryWithReferences,
)
from app.nodes.base import Node
from app.services.prompt_handler import PromptHandler
from app.utils.nodes_utils import time_execution, update_langsmith_metadata


class Summarizer(Node):
    """Summarizes retrieved documents to extract relevant information.

    Processes retrieved documents to create concise summaries with references
    to the original sources.

    Attributes:
        name: Identifier for this node in the graph
    """

    name = "summarizer"

    def __init__(
        self,
        instructor_client: AsyncInstructor,
        prompt_handler: PromptHandler,
    ) -> None:
        """Initializes the Summarizer node.

        Args:
            instructor_client: Client for making structured LLM calls
            prompt_handler: Service for retrieving prompt templates
        """
        self.instructor_client = instructor_client
        self.prompt_handler = prompt_handler

    @time_execution
    async def __call__(self, state: GraphState, config: RunnableConfig, writer: StreamWriter) -> GraphState:
        """Summarizes retrieved documents based on the original query.

        Processes documents retrieved from the knowledge base to create
        structured summaries with references to the source documents.

        Args:
            state: Current state of the graph
            config: Configuration for the node execution
            writer: Stream writer for streaming custom events

        Returns:
            Updated graph state with document summaries

        Raises:
            KeyError: If required configuration is missing
        """
        node_config = config.get("configurable", {}).get(self.name)
        if not node_config:
            raise KeyError(f"Configuration for node '{self.name}' is missing in 'configurable'.")
        if "model_name" not in node_config:
            raise KeyError(f"'model_name' is required in the configuration for node '{self.name}'.")
        if "fallback_model_name" not in node_config:
            raise KeyError(f"'fallback_model_name' is required in the configuration for node '{self.name}'.")

        context = state.nodes["retriever"].output["context"]
        structured_context = state.nodes["retriever"].output["structured_context"]
        steps: list[RetrievalStep] = state.nodes["planner"].output.steps

        system_prompt = [
            {
                "type": "text",
                "text": self.prompt_handler.get_prompt(path=f"{self.name}/template"),
            },
        ]

        inference_tasks = [
            self._process_step(
                step=step,
                docs=docs,
                node_config=node_config,
                system_prompt=system_prompt,
                writer=writer,
                query=state.query,
            )
            for docs, step in zip(context, steps)
        ]
        inference_results = await asyncio.gather(*inference_tasks)
        summaries, usage_info, model_info = zip(*inference_results)
        selected_references = [
            _select_elements_by_bracketed_ids(document_list=docs.documents, text=output.content)
            for docs, output in zip(structured_context, summaries)
        ]
        summaries_with_references = [
            XMLSummaryWithReferences.model_construct(
                content=output.content,
                references=[XMLReferences.model_construct(**ref.model_dump()) for ref in refs],
            )
            for output, refs in zip(summaries, selected_references)
        ]

        if node_config["fallback_model_name"] in set(model_info):
            model_used = node_config["fallback_model_name"]
        else:
            model_used = node_config["model_name"]
        update_langsmith_metadata(node=self, config=config, usage=usage_info, model_name=model_used)

        return GraphState(
            query=state.query,
            messages=state.messages,
            nodes={
                self.name: NodeResult(
                    output={
                        "summaries": summaries,
                        "xml_documents": [
                            summary.to_xml(encoding="utf-8").decode("utf-8")  # type: ignore
                            for summary in summaries_with_references
                        ],
                    },
                    usage=usage_info,
                )
            },
        )

    async def _process_step(
        self,
        step: RetrievalStep,
        docs: Any,
        node_config: dict[str, Any],
        system_prompt: list[dict[str, Any]],
        writer: StreamWriter,
        query: str,
    ) -> tuple[Summary, Any, str]:
        """Process a single retrieval step with fallback support.

        Args:
            step: The retrieval step to process
            docs: Document contexts for this step
            node_config: Configuration for this node
            system_prompt: System prompt
            writer: Stream writer for events
            query: The original user query

        Returns:
            Tuple of (summary, usage_info, model_name_used)
        """
        user_message: Any = {
            "role": "user",
            "content": [
                (
                    "<original_query> {{original_query}} </original_query>\n"
                    "<step_query> {{step_query}} </step_query>\n"
                    "<documents>\n"
                ),
                *docs,
                "</documents>",
            ],
        }
        context = {
            "original_query": query,
            "step_query": step.query,
        }

        primary_model = node_config["model_name"]
        fallback_model = node_config["fallback_model_name"]

        processing_id = str(uuid4())
        writer({"id": processing_id, "status": "started", "step": step.model_dump()})

        try:
            structured_output, usage = await self._attempt_model(
                model_name=primary_model,
                system_prompt=system_prompt,
                messages=[user_message],
                max_tokens=node_config.get("max_tokens", 8_912),
                temperature=node_config.get("temperature", 0.0),
                context=context,
            )
            model_used = primary_model
        except Exception as primary_error:
            logger.warning(
                "Primary model '{model}' failed for step '{s}' with error: '{error}'",
                model=primary_model,
                s=processing_id,
                error=str(primary_error),
            )

            try:
                structured_output, usage = await self._attempt_model(
                    model_name=fallback_model,
                    system_prompt=system_prompt,
                    messages=[user_message],
                    max_tokens=node_config.get("max_tokens", 8_912),
                    temperature=node_config.get("temperature", 0.0),
                    context=context,
                )
                model_used = fallback_model

            except Exception as fallback_error:
                logger.error(
                    "Both primary and fallback models failed for step '{s}'. Primary model error: '{primary_error}', Fallback model error: '{fallback_error}'",
                    s=processing_id,
                    primary_error=str(primary_error),
                    fallback_error=str(fallback_error),
                )
                raise Exception(f"Both primary and fallback models failed. Error: '{str(fallback_error)}'")

        writer({"id": processing_id, "status": "done", "step": step.model_dump()})
        return structured_output, usage, model_used

    async def _attempt_model(
        self,
        model_name: str,
        system_prompt: list[dict[str, Any]],
        messages: list[ChatCompletionMessageParam],
        max_tokens: int,
        temperature: float,
        context: dict[str, Any],
    ) -> tuple[Summary, Any]:
        """Attempt to use a specific model for summarization.

        Args:
            model_name: The model to use
            system_prompt: System prompt for this step
            messages: Messages for this step
            max_tokens: Maximum number of tokens in the response
            temperature: Temperature parameter for generation
            context: Map of variables to be used in the prompt

        Returns:
            Tuple of (structured_output, usage)
        """

        structured_output, usage = await self.instructor_client.chat.completions.create_with_completion(
            model=model_name,
            response_model=Summary,
            system=system_prompt,
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
            context=context,
        )

        return structured_output, usage


def _select_elements_by_bracketed_ids(document_list: list[Document], text: str) -> list[Document]:
    """Extracts documents referenced by bracketed IDs in the text.

    Parses the text for bracketed IDs (e.g., [1], [2]) and returns
    the corresponding documents from the document list.

    Args:
        document_list: List of documents to select from
        text: Text containing bracketed references to documents

    Returns:
        List of documents referenced in the text
    """
    ids_to_find = set(int(match.group(1)) for match in re.finditer(r"\[(\d+)\]", text))
    if not ids_to_find:
        return []

    result: list[Document] = []
    found_ids: set[int] = set()

    for element in document_list:
        if element.id in ids_to_find and element.id not in found_ids:
            result.append(element)
            found_ids.add(element.id)

            if len(found_ids) == len(ids_to_find):
                break

    return result
