from pathlib import Path
from typing import Any

import yaml


def get_runnable_config(config_file: str = "runnable_config.yaml") -> dict[str, Any]:
    """Get the runnable configuration from the provided YAML file.

    Args:
        config_file (str): Path to the YAML configuration file. Defaults to 'runnable_config.yaml'.
    """
    with Path(config_file).open("r") as f:
        return yaml.safe_load(f)
