from typing import Any, AsyncIterator

from fastapi import HTTPException, WebSocket
from fastapi.requests import HTTPConnection
from langgraph.graph.state import CompiledStateGraph
from psycopg import AsyncConnection, OperationalError


async def get_db_conn(
    request: HTTPConnection,
) -> AsyncIterator[AsyncConnection]:
    """Provides a database connection from the connection pool.

    Yields a connection from the pool and ensures it's properly closed after use.

    Args:
        request: The HTTP connection containing the database pool in its state.

    Yields:
        A database connection from the pool.
    """
    try:
        async with request.state.pool.connection() as conn:
            yield conn
    except OperationalError:
        raise HTTPException(status_code=500, detail="Could not connect to the database")
    except Exception:
        raise HTTPException(status_code=500, detail="Internal Server Error")


async def get_compiled_graph(websocket: WebSocket) -> CompiledStateGraph:
    """Retrieves the compiled LangGraph graph from the websocket state.

    Args:
        websocket: The WebSocket connection containing the graph in its state.

    Returns:
        The compiled LangGraph graph.
    """
    return websocket.state.graph


async def get_app_id(websocket: WebSocket) -> str:
    """Retrieves the app ID from the websocket state.

    Args:
        websocket: The WebSocket connection containing the app ID in its state.

    Returns:
        The app ID.
    """
    return websocket.state.app_id


async def get_runnable_config(websocket: WebSocket) -> dict[str, Any]:
    """Retrieves the runnable configuration from the websocket state.

    Args:
        websocket: The WebSocket connection containing the runnable configuration in its state.

    Returns:
        The runnable configuration.
    """
    return websocket.state.runnable_config
