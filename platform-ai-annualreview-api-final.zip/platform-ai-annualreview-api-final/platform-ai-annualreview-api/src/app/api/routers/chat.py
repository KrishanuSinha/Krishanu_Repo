from typing import Annotated, Any

from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect
from fastapi.encoders import jsonable_encoder
from langgraph.graph.state import CompiledStateGraph
from loguru import logger
from psycopg import AsyncConnection
from pydantic import UUID4

from app.api.dependencies import get_app_id, get_compiled_graph, get_db_conn, get_runnable_config
from app.database.queries import (
    get_conversation_history,
    insert_message,
)

router = APIRouter(tags=["chat"])


@router.websocket("/v1/annualreview/public/session/{session_id}/ask")
async def ask(
    websocket: WebSocket,
    session_id: UUID4,
    app_id: Annotated[str, Depends(get_app_id)],
    graph: Annotated[CompiledStateGraph, Depends(get_compiled_graph)],
    db_conn: Annotated[AsyncConnection, Depends(get_db_conn)],
    runnable_config: Annotated[dict[str, Any], Depends(get_runnable_config)],
) -> None:
    """Handle WebSocket connection for chat interactions.

    Establishes a WebSocket connection for real-time chat, processes user
    queries through the LangGraph workflow, and streams responses back to
    the client. Persists both user messages and assistant responses to the
    database.

    Args:
        websocket: The WebSocket connection to the client
        session_id: Unique identifier for the user session
        app_id: Unique identifier for the application
        graph: The compiled LangGraph workflow for processing queries
        db_conn: Database connection for persisting messages
    """
    await websocket.accept()
    logger.info("session_id: [{sess}] | started.", sess=session_id)

    try:
        async for query in websocket.iter_text():
            try:
                await insert_message(
                    conn=db_conn,
                    session_id=session_id,
                    role="user",
                    content=query,
                    json_content={},
                )

                messages = await get_conversation_history(
                    conn=db_conn,
                    session_id=session_id,
                )
                runnable_config_with_metadata = {
                    **runnable_config,
                    "metadata": {"session_id": str(session_id), "app_id": app_id},
                }

                try:
                    async for event in graph.astream_events(
                        input={
                            "query": query,
                            "messages": messages,
                        },
                        config=runnable_config_with_metadata,  # type: ignore
                        version="v2",
                        exclude_names=["_write"],
                        stream_mode=["custom"],
                    ):
                        kind = event.get("event", "")
                        name = event.get("name", "")
                        light_event = {
                            "event": kind,
                            "name": name,
                        }
                        if kind == "on_chain_stream" and name == "LangGraph":
                            jsonable_event = jsonable_encoder(obj=event)
                            light_event["data"] = jsonable_event.get("data", {})
                        await websocket.send_json(data=light_event)

                except WebSocketDisconnect:
                    logger.warning(f"WebSocket disconnected during stream: session_id={session_id}")
                    return  # Stop processing

                nodes_output = event["data"]["output"]["nodes"]  # type: ignore

                if "responder" in nodes_output:
                    response = nodes_output["responder"].output  # type: ignore
                elif "synthesizer" in nodes_output:
                    response = nodes_output["synthesizer"].output  # type: ignore
                else:
                    response = nodes_output["prohibited"].output  # type: ignore

                await insert_message(
                    conn=db_conn,
                    session_id=session_id,
                    role="assistant",
                    content=response["formatted_response"],  # type: ignore
                    json_content=response["structured_output"],  # type: ignore
                )

            except Exception as e:
                logger.error(f"Unexpected error during message processing: {e}")
                await websocket.send_json(
                    {
                        "event": "error",
                        "name": "fallback_response",
                        "data": {
                            "message": (
                                "Sorry we could not provide you with a response. "
                                "Please could you try the question again and if this issue persists please notify us at https://www.informa.com/investors/investor-relations-contacts/"
                            )
                        },
                    }
                )

    except WebSocketDisconnect:
        logger.warning(f"WebSocket connection closed by client: session_id={session_id}")
