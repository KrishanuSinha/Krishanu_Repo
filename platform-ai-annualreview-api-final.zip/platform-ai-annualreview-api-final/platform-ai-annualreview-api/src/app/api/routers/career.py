from fastapi import APIRouter, Depends
from pydantic import BaseModel
from ...models.nodes.career_state import SessionState
from ...nodes.career.types import NodeIO
from ...services.career_graph_builder import build_career_graph

router = APIRouter(prefix="/career", tags=["career"])

graph = build_career_graph()

class CareerRequest(BaseModel):
    utterance: str
    state: SessionState

@router.post("/run")
async def run(req: CareerRequest):
    io = NodeIO(state=req.state)
    result = graph.invoke(io)  # langgraph runtime
    return {"state": result.state.dict(), "trace": result.trace}
