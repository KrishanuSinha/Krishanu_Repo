from psycopg_pool import AsyncConnectionPool

from app.config.settings import Settings


def create_db_connection_pool(
    settings: Settings,
) -> AsyncConnectionPool:
    """Create a connection pool to the database.

    Initializes a PostgreSQL connection pool using the application settings.
    The pool is created in a closed state and must be explicitly opened
    before use.

    Args:
        settings: Application settings containing database configuration

    Returns:
        Configured but unopened connection pool to the database
    """
    return AsyncConnectionPool(conninfo=settings.database.conninfo, min_size=10, max_size=50, open=False)
