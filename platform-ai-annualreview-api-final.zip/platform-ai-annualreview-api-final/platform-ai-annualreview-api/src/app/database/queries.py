import json
from typing import Any, Literal, Optional

from fastapi import HTTPException
from psycopg import AsyncConnection, sql
from psycopg.rows import dict_row
from psycopg_pool import AsyncConnectionPool
from pydantic import UUID4


async def create_main_table(conn: AsyncConnection) -> None:
    """Create the conversations table if it doesn't exist.

    Sets up the main table for storing conversation messages with
    appropriate columns for session tracking, message content,
    and metadata.

    Args:
        conn: Active database connection
    """
    query = (
        "CREATE TABLE IF NOT EXISTS conversations ("
        "id SERIAL PRIMARY KEY,"
        "session_id UUID NOT NULL,"
        "timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
        "role VARCHAR(10) NOT NULL,"
        "content TEXT NOT NULL,"
        "json_content JSONB NOT NULL,"
        "UNIQUE (session_id, timestamp)"
        ");"
    )
    async with conn.cursor() as cur:
        await cur.execute(query=query)


async def create_tables(pool: AsyncConnectionPool) -> None:
    """Initialize all required database tables.

    Creates all necessary tables for the application using a connection
    from the provided pool.

    Args:
        pool: Database connection pool to acquire a connection from
    """
    async with pool.connection() as conn:
        await create_main_table(conn)


async def insert_message(
    conn: AsyncConnection,
    session_id: UUID4,
    role: Literal["system", "user", "assistant"],
    content: str,
    json_content: dict[str, Any],
) -> None:
    """Insert a new message into the conversations table.

    Stores a message with its associated session, role, content,
    and structured JSON content. Automatically commits the transaction.

    Args:
        conn: Active database connection
        session_id: Unique identifier for the conversation session
        role: Message sender role (system, user, or assistant)
        content: Plain text content of the message
        json_content: Structured data associated with the message
    """
    query = sql.SQL("INSERT INTO conversations (session_id, role, content, json_content) VALUES (%s, %s, %s, %s)")
    params = [str(session_id), role, content, json.dumps(json_content)]

    async with conn.cursor() as cur:
        await cur.execute(query=query, params=params)
        await conn.commit()


async def get_conversation_history(conn: AsyncConnection, session_id: UUID4) -> list[dict[str, str]]:
    """
    Retrieve the latest conversation history for a specific session.

    This function fetches up to the last 6 user-assistant message pairs from the
    conversation history stored in the database for a given session_id.
    Additionally, if the latest message is from the user and the assistant hasn't
    replied yet, it includes that user message as well.

    The results are returned in chronological order (oldest to newest) for passing to language models.

    Args:
        conn (AsyncConnection): Active asynchronous database connection.
        session_id (UUID4): Unique identifier for the conversation session.

    Returns:
        List of message dictionaries with role and content fields
    """
    query = sql.SQL(
        (
            """
            WITH msg AS (
            SELECT role, content, "timestamp",
                    ROW_NUMBER() OVER (ORDER BY "timestamp") AS rn
            FROM ai.conversations
            WHERE session_id = %s
            ),
            pairs AS (
            SELECT 
                u.rn AS user_rn, u."timestamp" AS user_ts, u.content AS user_content,
                a."timestamp" AS assistant_ts, a.content AS assistant_content
            FROM msg u
            JOIN msg a ON a.rn = u.rn + 1
            WHERE u.role = 'user' AND a.role = 'assistant'
            ),
            last_pairs AS (
            SELECT * FROM pairs ORDER BY user_ts DESC LIMIT 6
            ),
            flattened AS (
            SELECT 'user' AS role, user_content AS content, user_ts AS ts FROM last_pairs
            UNION ALL
            SELECT 'assistant', assistant_content, assistant_ts FROM last_pairs
            ),
            latest AS (
            SELECT role, content, "timestamp" AS ts
            FROM msg
            ORDER BY "timestamp" DESC
            LIMIT 1
            ),
            maybe_extra_user AS (
            SELECT role, content, ts FROM latest
            WHERE role = 'user'
                AND NOT EXISTS (
                SELECT 1 FROM msg
                WHERE role = 'assistant' AND "timestamp" > latest.ts
                )
            )
            SELECT role, content
            FROM (
            SELECT * FROM flattened
            UNION ALL
            SELECT * FROM maybe_extra_user
            ) AS final
            ORDER BY ts ASC;"""
        )
    )
    params = [str(session_id)]

    async with conn.cursor() as cur:
        await cur.execute(query=query, params=params)
        rows = await cur.fetchall()
        conversation_history = [{"role": row[0], "content": row[1]} for row in rows]
    return conversation_history


async def get_app_config_data(conn: AsyncConnection, app_id: UUID4) -> Optional[dict[str, Any]]:
    """Retrieve configuration data for a specific app.

    Fetches the ID, name, and metadata of an app from the database
    using the provided app ID.

    Args:
        conn: Active database connection.
        app_id: Unique identifier for the app.

    Returns:
        List of dictionaries containing the app's ID, name, and metadata.
    """
    query = sql.SQL("SELECT apps.id, apps.name, apps.cmetadata FROM apps WHERE apps.id = %s")
    params = [str(app_id)]

    async with conn.cursor(row_factory=dict_row) as cur:
        if not conn.closed:
            await cur.execute(query, params)
        else:
            raise HTTPException(status_code=500, detail="Database connection is closed")

        row = await cur.fetchone()
        return row or {}
