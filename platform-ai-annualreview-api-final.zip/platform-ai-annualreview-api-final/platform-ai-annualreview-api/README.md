<h1 align="center">Annual Report API</h1>
<div align="center">
    <a align="center" href="https://www.python.org/downloads/release/python-3128/"><img src="https://img.shields.io/badge/python-3.12.8-red"/></a>
    <a href="https://fastapi.tiangolo.com/"><img src="https://img.shields.io/badge/FastAPI-0.115.8-009688.svg?style=flat&logo=FastAPI&logoColor=white"/></a>
    <a href="https://github.com/astral-sh/uv"><img src="https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json"/></a>
    <a href="http://mypy-lang.org/"><img src="http://www.mypy-lang.org/static/mypy_badge.svg"/></a>
    <a href="https://github.com/astral-sh/ruff"><img src="https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json" alt="Ruff" style="max-width:100%;"></a>
</div>

<p align="center">
  <img src="assets/flow.png" alt="alt text">
</p>

## Stack
* Programming Language: [Python](https://www.python.org/)
* Dependency & Package Manager: [uv](https://docs.astral.sh/uv/)
* Framework: [FastAPI](https://fastapi.tiangolo.com/)
* Web Server: [Uvicorn](https://www.uvicorn.org/)
* Database: [PostgreSQL](https://www.postgresql.org/)
* LLM Providers: 
  * [Amazon Bedrock](https://aws.amazon.com/bedrock/)
* SDK/Clients:
  * [Instructor](https://python.useinstructor.com/)
  * [BAML](https://docs.boundaryml.com/guide/installation-language/python)
  * [Aiobotocore](https://aiobotocore.aio-libs.org/en/latest/)
* Orchestration: [LangGraph](https://www.langchain.com/langgraph)
* Monitoring: [LangSmith](https://www.langchain.com/langsmith/)
* Linters: [Ruff](https://docs.astral.sh/ruff/)
* Type Checking: [MyPy](https://mypy-lang.org/)
* Deployment: [Docker](https://www.docker.com/)

## Configuration
1. **Clone the Git repository:**
```shell
git clone git@github.com:Informa-IIRIS/platform-ai-annualreview-api.git
cd platform-ai-annualreview-api
```

2. **Rename the stub `.env copy` file to `.env` and replace placeholder values with the required credentials:**
```shell
mv .env\ copy .env
```
```
# GRAPH
ENV_NAME=local
DEBUG=false
PROMPTS_DIR=prompts

# AWS
AWS_BEDROCK_REGION=
AWS_KNOWLEDGE_BASE_ID=

# LANGSMITH
LANGSMITH_TRACING=true
LANGSMITH_ENDPOINT=
LANGSMITH_API_KEY=
LANGSMITH_PROJECT=

# POSTGRES
DB_NAME=
DB_USER=
DB_PASSWORD=
DB_HOST=
DB_PORT=
```

## Installation
There are two ways to run the application: using Docker or running it locally in the shell.

### Using `Docker`
1. **Ensure Docker is installed on your machine.** For more information, visit the official [Docker documentation](https://docs.docker.com/).
2. **Build the Docker images and start the containers:**
   ```shell
   make docker_build
   ```
3. **Run the application:**
   ```shell
   make docker_run
   ```
4. **Access the application.** Visit the default app path at [http://localhost:8000/docs](http://localhost:8000/docs). If everything is working correctly, you'll see the Swagger page.

5. **Shut down the container:**
   ```shell
   make docker_stop
   ```

### Running Locally in the Shell
1. **Install the dependencies and package:**
- With `uv`: *You will need to install `uv` first. For more information, visit the official [uv documentation](https://docs.astral.sh/uv/getting-started/installation/).*
```shell
uv sync --all-groups --frozen
source .venv/bin/activate  # Linux/MacOS
.venv\Scripts\activate     # Windows
```
- With `venv`:
```shell
python -m venv .venv
source .venv/bin/activate  # Linux/MacOS
.venv\Scripts\activate     # Windows
pip install -r requirements.txt
```
2. **Start the application:**
```shell
uvicorn server:app \
    --host 0.0.0.0 \
    --port 8000 \
    --reload
```
3. **Access the application.** Visit the default app path at [http://localhost:8000/docs](http://localhost:8000/docs). If everything is working correctly, you'll see the Swagger page.

4. **Stop the application.** This may involve using `Ctrl+C` in the terminal windows where the commands are running.

